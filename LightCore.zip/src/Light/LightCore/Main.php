<?php

# - Créditos ao LightDemon#5865, criador do plugin. Não venda este plugin!

namespace Light\LightCore;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as T;
use pocketmine\item\Item;

class Main extends PluginBase implements Listener{

 public $config = [];

	public function onEnable(): void{
		$this->reloadConfig();
 $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 $this->getLogger()->info("§l§f[§bLightCore§f] §b» §r§fPlugin ligado!");
	}
	
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{
		if($sender instanceof Player){
		  if(strtolower($command->getName() == "ajuda")){
			$this->Ajuda($sender);
			}
			if(strtolower($command->getName() == "equipe")){
			$this->Equipe($sender);
			}
			if(strtolower($command->getName() == "novidades")){
			$this->Novidades($sender);
			}
			if(strtolower($command->getName() == "vips")){
			$this->Vips($sender);
			}
			if(strtolower($command->getName() == "requisitos")){
	   $this->Requisitos($sender);
			}
			if(strtolower($command->getName() == "ip")){
		$sender->sendMessage($this->getConfig()->get("ip.msg"));
			}
			if(strtolower($command->getName() == "discord")){
		$sender->sendMessage($this->getConfig()->get("discord.msg"));
			}
			if(strtolower($command->getName() == "site")){
		$sender->sendMessage($this->getConfig()->get("site.msg"));
			}
		}
	return true;
	}
	
 public function Ajuda($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch ($result){
				case 0:
				$this->Equipe($player);
				break;
				
				case 1:
				$this->Novidades($player);
				break;
				
				case 2:
				$this->Vips($player);
				break;
				
				case 3:
				$this->Requisitos($player);
				break;
				
				case 4:
				break;

			}
		});
		$form->setTitle($this->getConfig()->get("ajuda.titulo"));
	$form->setContent($this->getConfig()->get("ajuda.msg"));

$form->addButton($this->getConfig()->get("equipe.botao"), 0, $this->getConfig()->get("imagem.equipe.botao"));

$form->addButton($this->getConfig()->get("novidades.botao"), 0, $this->getConfig()->get("imagem.novidades.botao"));

$form->addButton($this->getConfig()->get("vips.botao"), 0, $this->getConfig()->get("imagem.vips.botao"));

$form->addButton($this->getConfig()->get("requisitos.botao"), 0, $this->getConfig()->get("imagem.requisitos.botao"));
	$form->addButton($this->getConfig()->get("sair.botao"), 0, $this->getConfig()->get("imagem.sair.botao"));
        $player->sendForm($form);
	}
	
	public function Equipe($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch ($result){
				case 0:
				break;

			}
		});
		$form->setTitle($this->getConfig()->get("equipe.titulo"));
	$form->setContent($this->getConfig()->get("equipe.msg"));
	$form->addButton($this->getConfig()->get("sair.botao"), 0, $this->getConfig()->get("imagem.sair.botao"));
        $player->sendForm($form);
	}
	
	public function Novidades($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch ($result){
				case 0:
				break;

			}
		});
		$form->setTitle($this->getConfig()->get("novidades.titulo"));
	$form->setContent($this->getConfig()->get("novidades.msg"));
	$form->addButton($this->getConfig()->get("sair.botao"), 0, $this->getConfig()->get("imagem.sair.botao"));
        $player->sendForm($form);
	}
	
	public function Vips($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch ($result){
				case 0:
				break;

			}
		});
		$form->setTitle($this->getConfig()->get("vips.titulo"));
	$form->setContent($this->getConfig()->get("vips.msg"));
	$form->addButton($this->getConfig()->get("sair.botao"), 0, $this->getConfig()->get("imagem.sair.botao"));
        $player->sendForm($form);
	}
	
	public function Requisitos($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch ($result){
				case 0:
				break;

			}
		});
		$form->setTitle($this->getConfig()->get("requisitos.titulo"));
	$form->setContent($this->getConfig()->get("requisitos.msg"));
	
$form->addButton($this->getConfig()->get("sair.botao"), 0, $this->getConfig()->get("imagem.sair.botao"));
        $player->sendForm($form);
	}
}